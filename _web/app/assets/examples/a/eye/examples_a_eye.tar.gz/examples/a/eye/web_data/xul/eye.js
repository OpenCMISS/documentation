function RunnableFunctionWrapper(aFunction)
{
  this.run = aFunction;
}

RunnableFunctionWrapper.prototype =
{
  QueryInterface: function(aIID)
  {
    if (aIID.equals(Components.interfaces.nsIRunnable) ||
        aIID.equals(Components.interfaces.nsISupports))
      return this;
    throw Components.results.NS_NOINTERFACE;
  }
};


function CmguiReady()
{
}


CmguiReady.prototype =
{
  QueryInterface: function(aIID)
  {
    if (
        aIID.equals(Components.interfaces.CmguiIApplicationBootstrap) ||
        aIID.equals(Components.interfaces.CmguiISceneViewerResultMonitor) ||
	aIID.equals(Components.interfaces.nsISupports)
       )
    {
      return this;
    }
    throw Components.results.NS_NOINTERFACE;
  },

  cmguiReady: function(cdf)
  {
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    window.commandData = cdf.createCommandData();

    // for a switch in the comfile that stops cmgui opening graphics windows
    // also stops the emoter which doesn't work outside motif
    window.commandData.executeCommand("$ZINC=1");

	 load_files();
  },

  sceneViewerReady: function(sceneViewer)
  {
    // This is just a sample of how this interface could be put on the cmguiReady object.
    // However in this demo we define scene1Ready object to handle the initialisation of the scene following
    // downloading of the content and execution of the command file. 
  }
};



function scene1Ready()
{
}


scene1Ready.prototype =
{
  QueryInterface: function(aIID)
  {
    if (
        aIID.equals(Components.interfaces.CmguiISceneViewerResultMonitor)
       )
    {
      return this;
    }
    throw Components.results.NS_NOINTERFACE;
  },

  sceneViewerReady: function(sceneViewer)
  {
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
    window.plugin.resizeMonitor =
      mozCmguiProxyToMain(new mozCmguiResizeMonitor(sceneViewer, window.plugin),
                  Components.interfaces.mozIPluginResizeMonitor);

	 window.sceneViewer = sceneViewer;

    // Once we have scene viewers, we need to use a function calling mechanism that avoids
    // deadlocks on the Microsoft Windows Platform, on other platforms this wrapper executes 
    //the function as before.
    //mozCmguiRunSafe(function(){window.commandData.executeCommand("print bob");});
    mozCmguiRunSafe(function(){sceneViewer.setBackgroundColourRGB(0.0, 0.0, 0.0);});
    mozCmguiRunSafe(function(){sceneViewer.setWindowSize(window.plugin.width, window.plugin.height);});
    mozCmguiRunSafe(function(){sceneViewer.viewAll();});
    mozCmguiRunSafe(function(){window.sceneViewer.setLookatParametersNonSkew(303.352, 394.3, -121.142, 303.352, 252.34, -121.142, 0, 0, 1 );});
    mozCmguiRunSafe(function(){sceneViewer.viewAngle = 0.32;}); // radians

	 try
	 {
		 // Doesn't matter if this fails, just nice if it works.
		 //mozCmguiRunSafe(function(){sceneViewer.transparencyMode = Components.interfaces.CmguiISceneViewer.TRANSPARENCY_ORDER_INDEPENDENT;});
		 //mozCmguiRunSafe(function(){sceneViewer.transparencyLayers = 5;});
	 }
	 catch (e)
	 {
	 }
  }
};

function load_files()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    //  from local file system
    // Note the downloading is asynchronous so we need to wait for all of these to finish before
    // continuing. The DownloadMonitor object keeps track of the number of downloads in progress.
    // A counter will be incremented when an asynchronous download is started
    // and decremented when download is complete and the memory block defined
    // When counter returns to 0 the callback function will be executed, ie carry on.
    // 
    // Note there is a very small race condition here. The first download could complete
    // before the second has started.
    var dm = Components.classes["@physiome.org/mozCmgui/mozDownloadMonitor;1"]
                      .createInstance(Components.interfaces.mozIDownloadMonitor);
    dm.onDownloadsCompleted = new RunnableFunctionWrapper(runComfile);

    var files = [
		 "arteries_angle_long.exnode",
		 "arteries_angle_short.exelem",
		 "arteries_angle_short.exnode",
		 "butterfly.jpg",
		 "choroidConstrict_fitted_fitted2.exnode",
		 "choroidDilate_fitted_fitted2.exelem",
		 "choroidDilate_fitted_fitted2.exnode",
		 "choroid_angle_long.exelem",
		 "choroid_angle_long.exnode",
		 "choroid_angle_short.exelem",
		 "choroid_angle_short.exnode",
		 "elements_on.com",
		 "eye.com",
		 "eye_photo_mapped_choroid.tiff",
		 "eye_photo_mapped_irisblue.tiff",
		 "eye_photo_mapped_irisbrown.tiff",
		 "eye_photo_mapped_irisgrey.tiff",
		 "eye_photo_mapped_irislightbrown.tiff",
		 "eye_photo_mapped_irislightbrown2.tiff",
		 "eye_photo_mapped_irisgreen.tiff",
		 "eye_photo_mapped_retina.tiff",
		 "fitted_orbit.exelem",
		 "fitted_orbit.exnode",
		 "infobl2.exelem",
		 "infobl2.exnode",
		 "infrec2.exelem",
		 "infrec2.exnode",
		 "latrect2.exelem",
		 "latrect2.exnode",
		 "lens_fitted.exnode",
		 "lens_fitted.exelem",
		 "medrect2.exelem",
		 "medrect2.exnode",
		 "opticNerve_long.exelem",
		 "opticNerve_long.exnode",
		 "opticNerve_short.exelem",
		 "opticNerve_short.exnode",
		 "retina_angle_long.exnode",
		 "retina_angle_short.exelem",
		 "retina_angle_short.exnode",
		 "sclera_angle_long.exnode",
		 "sclera_angle_short.exelem",
		 "sclera_angle_short.exnode",
		 "skin.exelem",
		 "skin.exnode",
		 "sky.jpg",
		 "supobl2.exelem",
		 "supobl2.exnode",
		 "suprec2.exelem",
		 "suprec2.exnode",
		 "surfaces_on.com",
		 "texture_block.exelem",
		 "texture_block.exnode",
		 "texture_block2.exelem",
		 "texture_block2.exnode",
		 "texture_block3.exelem",
		 "texture_block3.exnode",
		 "tree.jpg",
		 "trochlea_moved.exelem",
		 "trochlea_moved.exnode",
		 "veins_angle_long.exnode",
		 "veins_angle_short.exelem",
		 "veins_angle_short.exnode",
		 "zonules_trans2.exnode",
		 "zonules_trans2.exelem"
		 ];

	 for (i = 0 ;  i < files.length ; i++)
	 {
		 filename = '../../cmiss_input/' + files[i];
		 memoryname = '/' + files[i];

		 try
		 {
			 window.mozCmguiDefineMemoryBlock(commandData, dm, filename, memoryname);
		 }
		 catch (e)
		 {
			 alert ('Unable to find required file ' + filename);
		 }
	 }
}



function runComfile()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  //mozCmguiRunSafe(function(){window.commandData.executeCommand('print \"runComfile just entered\\n\"');});
  mozCmguiRunSafe(function(){window.commandData.executeCommand("$example = \"memory:\";");});
  mozCmguiRunSafe(function(){window.commandData.executeCommand("open comfile memory:/eye.com exec;");});

  mozCmguiRunSafe(function(){document.getElementById("iris-slider").addEventListener("DOMAttrModified", iris_slider, false);});
  mozCmguiRunSafe(function(){document.getElementById("length-slider").addEventListener("DOMAttrModified", length_slider, false);});
  //mozCmguiRunSafe(function(){document.getElementById("focus-slider").addEventListener("DOMAttrModified", focus_slider, false);});



  window.surfacesVisible = true;
  window.irisColour = 'blue';
  update_iris_colour();

  window.depthOfField = 0.0;
  window.minimumFocalDepth = -0.52;
  window.rangeFocalDepth = 0.48;
  window.sliderFocalDepth = 0.0;
  window.offsetFocalDepth = 0.0;


  var plugin = document.getElementById("generalplugin");
  window.plugin = plugin;
  var windowId = plugin.window;

    window.commandData.createSceneViewer(windowId,
    mozCmguiProxyToMain(new scene1Ready(), 
    Components.interfaces.CmguiISceneViewerResultMonitor));

}

function init()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var minVersion = "0.4.0.0";
  var maxVersion = "0.5.0";

  if (mozCmguiCheckValidVersion(minVersion, maxVersion))
  {
        mozCmguiInitialise(new CmguiReady());
  }
  else
  {
    actualVersion = mozCmguiVersion();
    alert("The installed version of mozCmgui is not valid for this application. \n" +
		 "Version installed : " + actualVersion +
		 "\nMinimum allowable version :" + minVersion +
		 "\nMaximum allowable version :" + maxVersion + "\n");
  }
}

//################### Functions for structures visibility #############################
function toggle_medrect()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis medrect/medrect');});
}

function toggle_latrect()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis latrect/latrect');});
}

function toggle_infrec()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis infrec/infrec');});
}

function toggle_suprec()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis suprec/suprec');});
}

function toggle_infobl()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis infobl/infobl');});
}

function toggle_supobl()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis supobl/supobl');});
}

function toggle_opticNerve()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis opticNerve/opticNerve');});
}

function toggle_sclera()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis sclera/sclera');});
}

function toggle_cornea()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis sclera/cornea');});
}

function toggle_choroid()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

 mozCmguiRunSafe(function(){ window.commandData.executeCommand('gfx set vis choroid_back/choroid2_fitted');});
}

function toggle_ciliaryBody()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis choroid/ciliaryBody');});
}

function toggle_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis choroid/iris');});
}

function toggle_retina()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis retina/retina');});
}

function toggle_macula()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis retina/macula');});
}

function toggle_zonules()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis zonules/zonules');});
}

function toggle_lens()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis lens/lens');});
}

function toggle_arteries()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis arteries/arteries');});
}

function toggle_veins()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis veins/veins');});
}

function toggle_bones()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis bone/fitted_orbit');});
}

function toggle_skin()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis skins/final_skin');});
}

function toggle_trochlea()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis trochlea/trochlea_moved');});
}

//################### Functions for various views #############################
function anterior_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

//  var plugin = document.getElementById("generalplugin");
//  var viewer = plugin.sceneViewer;

//  window.plugin = plugin;
//  var windowId = plugin.window;
//  var viewer = plugin.sceneViewer;
//  eye point, interest point, then up vectors
  mozCmguiRunSafe(function(){
	window.sceneViewer.setLookatParametersNonSkew(303.352, 389.176, -121.142, 
							303.352, 252.34, -121.142, 
							-0, -0, 1);
	});
}

function superior_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){
	window.sceneViewer.setLookatParametersNonSkew(303.352, 252.34, 20.818, 
							303.352, 252.34, -121.142, 
							-0, 1, -0);
	});
}

function inferior_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){
	window.sceneViewer.setLookatParametersNonSkew(303.352, 251.032, -259.119, 
							303.352, 251.34, -121.142, 
							-0, 1, -0);
	});
}

function left_side_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){
	window.sceneViewer.setLookatParametersNonSkew(161.392, 252.34, -121.142, 
							303.352, 252.34, -121.142, 
							-0, -0, 1);
	});
}

function right_side_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){
	window.sceneViewer.setLookatParametersNonSkew(445.313, 252.34, -121.142, 
							303.352, 252.34, -121.142, 
							-0, -0, 1);
	});
}

function inside_out_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){ 
	window.sceneViewer.setLookatParametersNonSkew(307.488, 264.866, -119.958, 
							307.5, 265, -120, 
							0.0203336, 0.297366, 0.954547);
	});
  	//window.commandData.executeCommand('gfx set vis sclera/cornea off');
  	//window.commandData.executeCommand('gfx set vis lens/lens off'); 
   mozCmguiRunSafe(function(){window.sceneViewer.setNearAndFarPlane(0.01,633.343);});

  //Radians
   mozCmguiRunSafe(function(){window.sceneViewer.viewAngle = 177.451*3.14/180.0;});
}


function view_all()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis skins/final_skin off');});
  mozCmguiRunSafe(function(){window.sceneViewer.viewAll();});
  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx set vis skins/final_skin on');});
}

//################### Functions for iris colors ################################
function update_iris_colour()
{
	if(window.surfacesVisible)
	{
	  is_delete = '';
	}
        else
	{
	  is_delete = ' delete';
	}
  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx modify g_element choroid/iris surfaces exterior face xi2_0 select_on material photo_mapped_iris_' + window.irisColour + ' texture_coordinates xi_texture_coordinates_iris selected_material default_selected render_shaded' + is_delete);});
  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx modify g_element choroid/iris surfaces exterior face xi2_1 select_on material photo_mapped_iris_' + window.irisColour + ' texture_coordinates xi_texture_coordinates_iris selected_material default_selected render_shaded' + is_delete);});
  mozCmguiRunSafe(function(){window.commandData.executeCommand('gfx modify g_element choroid/iris surfaces exterior face xi3_1 select_on material photo_mapped_iris_' + window.irisColour + ' texture_coordinates xi_texture_coordinates_iris selected_material default_selected render_shaded' + is_delete);});
}

function brown_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'brown';
  update_iris_colour();
 }

function blue_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'blue';
  update_iris_colour();

}

function grey_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'grey';
  update_iris_colour();
}

function green_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'green';
  update_iris_colour();
}

function lightbrown_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = "lightbrown";
  update_iris_colour();

}

function lighterbrown_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

   window.irisColour = "lightbrown2";
   update_iris_colour();
}

//################### Functions for background colors #############################
function back_white()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  mozCmguiRunSafe(function(){sceneViewer.setBackgroundColourRGB(1.0, 1.0, 1.0);});
}

function back_black()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  mozCmguiRunSafe(function(){sceneViewer.setBackgroundColourRGB(0.0, 0.0, 0.0);});
}

function back_bluey()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  mozCmguiRunSafe(function(){sceneViewer.setBackgroundColourRGB(0.1, 0.1, 0.2);});
}

//################### Functions for sliders ####################################
function iris_slider()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
	
  var irisSlider = document.getElementById("iris-slider");

  // These attributes must be specified in the xul so that they are fetchable
  irisSlider.maxValue = irisSlider.getAttribute("maxpos");
  irisSlider.value = irisSlider.getAttribute("curpos");

  // Unfortunately we are grabbing mouse move events and we have to check if 
  // the value has actually changed.
  if (irisSlider.previousValue != irisSlider.value)
  {
	irisSlider.previousValue = irisSlider.value;

   	window.commandData.executeCommand("gfx define field pupil_time constant " + irisSlider.value / irisSlider.maxValue);
  }
}

function length_slider()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
	
  var lengthSlider = document.getElementById("length-slider");

  // These attributes must be specified in the xul so that they are fetchable
  lengthSlider.maxValue = lengthSlider.getAttribute("maxpos");
  lengthSlider.value = lengthSlider.getAttribute("curpos");

  // Unfortunately we are grabbing mouse move events and we have to check if 
  // the value has actually changed.
  if (lengthSlider.previousValue != lengthSlider.value)
  {
	lengthSlider.previousValue = lengthSlider.value;

   	window.commandData.executeCommand("gfx define field length_time constant " + ((lengthSlider.value / lengthSlider.maxValue) * 2.0 + (-1.0)));  
  }
}

function update_depth_of_field()
{
	netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	window.sceneViewer.setDepthOfField(window.depthOfField, window.sliderFocalDepth + window.offsetFocalDepth);
}

function focus_slider()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
	
  var focusSlider = document.getElementById("focus-slider");

  // These attributes must be specified in the xul so that they are fetchable
  focusSlider.maxValue = focusSlider.getAttribute("maxpos");
  focusSlider.value = focusSlider.getAttribute("curpos");

  // Unfortunately we are grabbing mouse move events and we have to check if 
  // the value has actually changed.
  if (focusSlider.previousValue != focusSlider.value)
  {
	focusSlider.previousValue = focusSlider.value;

	window.sliderFocalDepth = (focusSlider.value / focusSlider.maxValue) * window.rangeFocalDepth + window.minimumFocalDepth; 

	update_depth_of_field();

   	window.commandData.executeCommand("gfx define field lens_time constant " + ((focusSlider.value / focusSlider.maxValue) * 2.0 + (-1.0))); 

  }
}


function infinite_depth_of_field()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.depthOfField = 0.0;
  update_depth_of_field();

    mozCmguiRunSafe(function(){document.getElementById("close-label").setAttribute("disabled", "true");});
    mozCmguiRunSafe(function(){document.getElementById("focus-slider").setAttribute("disabled", "true");});
    mozCmguiRunSafe(function(){document.getElementById("far-label").setAttribute("disabled", "true");});  
}

function normal_eye_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.depthOfField = 0.015;
  window.offsetFocalDepth = 0.0;
  update_depth_of_field();
    mozCmguiRunSafe(function(){document.getElementById("close-label").setAttribute("disabled", "false");});
    mozCmguiRunSafe(function(){document.getElementById("focus-slider").setAttribute("disabled", "false");});
    mozCmguiRunSafe(function(){document.getElementById("far-label").setAttribute("disabled", "false");})
}

function short_sighted_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.depthOfField = 0.015;
  window.offsetFocalDepth = -0.2;

  update_depth_of_field();
    mozCmguiRunSafe(function(){document.getElementById("close-label").setAttribute("disabled", "false");});
    mozCmguiRunSafe(function(){document.getElementById("focus-slider").setAttribute("disabled", "false");});
    mozCmguiRunSafe(function(){document.getElementById("far-label").setAttribute("disabled", "false");});  
}

function long_sighted_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.depthOfField = 0.015;
  window.offsetFocalDepth = 0.2;

  update_depth_of_field();
    mozCmguiRunSafe(function(){document.getElementById("close-label").setAttribute("disabled", "false");});
    mozCmguiRunSafe(function(){document.getElementById("focus-slider").setAttribute("disabled", "false");});
    mozCmguiRunSafe(function(){document.getElementById("far-label").setAttribute("disabled", "false");}); 
}

function lines_on()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var displayLines = document.getElementById("lines-on");

if ("true" == displayLines.getAttribute("checked"))
	{
  mozCmguiRunSafe(function(){window.commandData.executeCommand("$is_delete = '';");});
  mozCmguiRunSafe(function(){window.commandData.executeCommand("open comfile memory:/elements_on.com exec;");});
    mozCmguiRunSafe(function(){window.sceneViewer.perturbLines = true;});
	}
else
	{
  mozCmguiRunSafe(function(){window.commandData.executeCommand("$is_delete = 'delete';");});
  mozCmguiRunSafe(function(){window.commandData.executeCommand("open comfile memory:/elements_on.com exec;");});
    mozCmguiRunSafe(function(){window.sceneViewer.perturbLines = false;});
	}

}

function surfaces_on()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var displaySurfaces = document.getElementById("surfaces-on");

if ("true" == displaySurfaces.getAttribute("checked"))
	{
  mozCmguiRunSafe(function(){window.commandData.executeCommand("$is_delete = '';");});
  mozCmguiRunSafe(function(){window.commandData.executeCommand("open comfile memory:/surfaces_on.com exec;");});

  window.surfacesVisible = true;
  update_iris_colour();

	}
else
	{
  mozCmguiRunSafe(function(){window.commandData.executeCommand("$is_delete = 'delete';");});
   mozCmguiRunSafe(function(){window.commandData.executeCommand("open comfile memory:/surfaces_on.com exec;");});

  window.surfacesVisible = false;
  update_iris_colour();

	}

}

function destroy()
{
  window.plugin = null;
  window.commandData = null;
  window.sceneViewer = null;
  window.mcg = null;
}
