function RunnableFunctionWrapper(aFunction)
{
  this.run = aFunction;
}

RunnableFunctionWrapper.prototype =
{
  QueryInterface: function(aIID)
  {
    if (aIID.equals(Components.interfaces.nsIRunnable) ||
        aIID.equals(Components.interfaces.nsISupports))
      return this;
    throw Components.results.NS_NOINTERFACE;
  }
};


function CmguiReady()
{
}


function CmguiReadyFunction(zincCommandData)
  {
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    window.commandData = zincCommandData

    // for a switch in the comfile that stops cmgui opening graphics windows
    // also stops the emoter which doesn't work outside motif
    window.commandData.executeCommand("$ZINC=1");

	 load_files();
  
}



function scene1Ready()
{
}


function scene1ReadyFunction(sceneViewer)
  {
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	 window.sceneViewer = sceneViewer;

    // Once we have scene viewers, we need to use a function calling mechanism that avoids
    // deadlocks on the Microsoft Windows Platform, on other platforms this wrapper executes 
    //the function as before.
    //window.commandData.executeCommand("print bob");
    sceneViewer.setBackgroundColourRGB(0.0, 0.0, 0.0);
    sceneViewer.viewAll();
    window.sceneViewer.setLookatParametersNonSkew(303.352, 394.3, -121.142, 303.352, 252.34, -121.142, 0, 0, 1 );
    sceneViewer.viewAngle = 0.32; // radians

	 try
	 {
		 // Doesn't matter if this fails, just nice if it works.
		 //sceneViewer.transparencyMode = Components.interfaces.CmguiISceneViewer.TRANSPARENCY_ORDER_INDEPENDENT;
		 //sceneViewer.transparencyLayers = 5;
	 }
	 catch (e)
	 {
	 }

	 if (window.location.hash == "#test")
	 {
		 run_tests();
	 }

  
}

function load_files()
{
    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

    //  from local file system
    // Note the downloading is asynchronous so we need to wait for all of these to finish before
    // continuing. The DownloadMonitor object keeps track of the number of downloads in progress.
    // A counter will be incremented when an asynchronous download is started
    // and decremented when download is complete and the memory block defined
    // When counter returns to 0 the callback function will be executed, ie carry on.
    // 
    // Note there is a very small race condition here. The first download could complete
    // before the second has started.
    var dm = zincCreateDownloadMonitor(window.commandData, runComfile);

    var files = [

		 "arteries_angle_long.exnode",
		 "arteries_angle_short.exelem",
		 "arteries_angle_short.exnode",
		 "butterfly.jpg",
		 "choroidConstrict_fitted_fitted2.exnode",
		 "choroidDilate_fitted_fitted2.exelem",
		 "choroidDilate_fitted_fitted2.exnode",
		 "choroid_angle_long.exelem",
		 "choroid_angle_long.exnode",
		 "choroid_angle_short.exelem",
		 "choroid_angle_short.exnode",
		 "elements_on.com",
		 "eye2.com",
		 "eye_photo_mapped_choroid.tiff",
		 "eye_photo_mapped_irisblue.tiff",
		 "eye_photo_mapped_irisbrown.tiff",
		 "eye_photo_mapped_irisgrey.tiff",
		 "eye_photo_mapped_irislightbrown.tiff",
		 "eye_photo_mapped_irislightbrown2.tiff",
		 "eye_photo_mapped_irisgreen.tiff",
		 "eye_photo_mapped_retina.tiff",
		 "fitted_orbit.exelem",
		 "fitted_orbit.exnode",
		 "infobl2.exelem",
		 "infobl2.exnode",
		 "infrec2.exelem",
		 "infrec2.exnode",
		 "latrect2.exelem",
		 "latrect2.exnode",
		 "lens_fitted_flatten.exnode",
		 "lens_fitted_rounded.exnode",
		 "lens_fitted_rounded.exelem",
		 "medrect2.exelem",
		 "medrect2.exnode",
		 "opticNerve_long.exelem",
		 "opticNerve_long.exnode",
		 "opticNerve_short.exelem",
		 "opticNerve_short.exnode",
		 "ray1_flatten.exnode",
		 "ray1_rounded.exelem",
		 "ray1_rounded.exnode",
		 "ray2_flatten.exnode",
		 "ray2_rounded.exelem",
		 "ray2_rounded.exnode",
		 "ray3_flatten.exnode",
		 "ray3_rounded.exelem",
		 "ray3_rounded.exnode",
		 "retina_angle_long.exnode",
		 "retina_angle_short.exelem",
		 "retina_angle_short.exnode",
		 "sclera_angle_long.exnode",
		 "sclera_angle_short.exelem",
		 "sclera_angle_short.exnode",
		 "skin.exelem",
		 "skin.exnode",
		 "sky.jpg",
		 "supobl2.exelem",
		 "supobl2.exnode",
		 "suprec2.exelem",
		 "suprec2.exnode",
		 "surfaces_on.com",
		 "texture_block.exelem",
		 "texture_block.exnode",
		 "texture_block2.exelem",
		 "texture_block2.exnode",
		 "texture_block3.exelem",
		 "texture_block3.exnode",
		 "tree.jpg",
		 "trochlea_moved.exelem",
		 "trochlea_moved.exnode",
		 "veins_angle_long.exnode",
		 "veins_angle_short.exelem",
		 "veins_angle_short.exnode",
		 "zonules_trans2.exnode",
		 "zonules_trans2.exelem"
		 ];

	 for (i = 0 ;  i < files.length ; i++)
	 {
		 filename = '../../cmiss_input/' + files[i];
		 memoryname = '/' + files[i];

		 try
		 {
			 zincDefineMemoryBlock( dm, filename, memoryname);
		 }
		 catch (e)
		 {
			 alert ('Unable to find required file ' + filename);
		 }
	 }
}



function runComfile()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  //window.commandData.executeCommand('print \"runComfile just entered\\n\"');
  window.commandData.executeCommand("$example = \"memory:\";");
  window.commandData.executeCommand("open comfile memory:/eye2.com exec;");

  document.getElementById("iris-slider").addEventListener("DOMAttrModified", iris_slider, false);
  window.focusSlider = document.getElementById("focus-slider");
  var minVersion = "0.6.0.1"
	  var maxVersion = "0" // We are already checking max version further down

  if (zincCheckValidVersion(minVersion, maxVersion))
  {
    document.getElementById("focus-slider").addEventListener("DOMAttrModified", focus_slider, false);
  }
  else
  {
    //window.focusSlider.setAttribute("disabled", "false");
    document.getElementById("normal-eye").setAttribute("disabled", "true");  
    document.getElementById("short-sighted").setAttribute("disabled", "true");  
    document.getElementById("long-sighted").setAttribute("disabled", "true");  
    document.getElementById("close-label").setAttribute("disabled", "true");
    document.getElementById("focus-slider").setAttribute("disabled", "true");
    document.getElementById("far-label").setAttribute("disabled", "true");  
    document.getElementById("version-label").setAttribute("value", "Requires Version 0.4.1.5");
  }

  window.depthOfField = 0.0;
  window.minimumFocalDepth = -0.52;
  window.rangeFocalDepth = 0.48;
  window.sliderFocalDepth = 0.0;
  window.offsetFocalDepth = 0.0;

  window.surfacesVisible = true;
  window.simulateDepth = false;
  window.depthOfField = 0.015;
  window.irisColour = 'blue';
  update_iris_colour();


  var plugin = document.getElementById("generalplugin");

    zincCreateSceneViewer(plugin, window.commandData,
    scene1ReadyFunction);

}

function init()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var minVersion = "0.6.3"
  var maxVersion = "0.6.4.4"

  if (zincCheckValidVersion(minVersion, maxVersion))
  {
    zincInitialise(CmguiReadyFunction);
  }
  else
  {
    actualVersion = zincVersion();
    alert("The installed version of zinc is not valid for this application. \n" +
		 "Version installed : " + actualVersion +
		 "\nMinimum allowable version :" + minVersion +
		 "\nMaximum allowable version :" + maxVersion + "\n");
  }
}

//################### Functions for structures visibility #############################
function toggle_medrect()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis medrect/medrect');
}

function toggle_latrect()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis latrect/latrect');
}

function toggle_infrec()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis infrec/infrec');
}

function toggle_suprec()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis suprec/suprec');
}

function toggle_infobl()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis infobl/infobl');
}

function toggle_supobl()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis supobl/supobl');
}

function toggle_opticNerve()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis opticNerve/opticNerve');
}

function toggle_sclera()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis sclera/sclera');
}

function toggle_cornea()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis sclera/cornea');
}

function toggle_choroid()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis choroid_back/choroid2_fitted');
}

function toggle_ciliaryBody()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis choroid/ciliaryBody');
}

function toggle_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis choroid/iris');
}

function toggle_retina()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis retina/retina');
}

function toggle_macula()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis retina/macula');
}

function toggle_zonules()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis zonules/zonules');
}

function toggle_lens()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis lens/lens');
}

function toggle_arteries()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis arteries/arteries');
}

function toggle_veins()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis veins/veins');
}

function toggle_bones()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis bone/fitted_orbit');
}

function toggle_skin()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis skins/final_skin');
}

function toggle_trochlea()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis trochlea/trochlea_moved');
}

//################### Functions for various views #############################
function anterior_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");


//  eye point, interest point, then up vectors
	window.sceneViewer.setLookatParametersNonSkew(303.352, 389.176, -121.142, 
							303.352, 252.34, -121.142, 
							-0, -0, 1);
}

function superior_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	window.sceneViewer.setLookatParametersNonSkew(303.352, 252.34, 20.818, 
							303.352, 252.34, -121.142, 
							-0, 1, -0);
}

function inferior_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	window.sceneViewer.setLookatParametersNonSkew(303.352, 251.032, -259.119, 
							303.352, 251.34, -121.142, 
							-0, 1, -0);
}

function left_side_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	window.sceneViewer.setLookatParametersNonSkew(161.392, 252.34, -121.142, 
							303.352, 252.34, -121.142, 
							-0, -0, 1);
}

function right_side_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	window.sceneViewer.setLookatParametersNonSkew(445.313, 252.34, -121.142, 
							303.352, 252.34, -121.142, 
							-0, -0, 1);
}

function inside_out_view()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	window.sceneViewer.setLookatParametersNonSkew(307.488, 264.866, -119.958, 
							307.5, 265, -120, 
							0.0203336, 0.297366, 0.954547);
  	//window.commandData.executeCommand('gfx set vis sclera/cornea off');
  	//window.commandData.executeCommand('gfx set vis lens/lens off'); 
	window.sceneViewer.setNearAndFarPlane(0.01,633.343);

  //Radians
   window.sceneViewer.viewAngle = 177.451*3.14/180.0;
}


function view_all()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.commandData.executeCommand('gfx set vis block/texture_block off');
  window.commandData.executeCommand('gfx set vis block/texture_block2 off');
  window.commandData.executeCommand('gfx set vis block/texture_block3 off');
  window.sceneViewer.viewAll();
  window.commandData.executeCommand('gfx set vis block/texture_block on');
  window.commandData.executeCommand('gfx set vis block/texture_block2 on');
  window.commandData.executeCommand('gfx set vis block/texture_block3 on');
}

//################### Functions for iris colors ################################
function update_iris_colour()
{
	if(window.surfacesVisible)
	{
	  is_delete = '';
	}
        else
	{
	  is_delete = ' delete';
	}
  window.commandData.executeCommand('gfx modify g_element choroid/iris surfaces exterior face xi2_0 select_on material photo_mapped_iris_' + window.irisColour + ' texture_coordinates xi_texture_coordinates_iris selected_material default_selected render_shaded' + is_delete);
  window.commandData.executeCommand('gfx modify g_element choroid/iris surfaces exterior face xi2_1 select_on material photo_mapped_iris_' + window.irisColour + ' texture_coordinates xi_texture_coordinates_iris selected_material default_selected render_shaded' + is_delete);
  window.commandData.executeCommand('gfx modify g_element choroid/iris surfaces exterior face xi3_1 select_on material photo_mapped_iris_' + window.irisColour + ' texture_coordinates xi_texture_coordinates_iris selected_material default_selected render_shaded' + is_delete);
}

function brown_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'brown';
  update_iris_colour();
 }

function blue_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'blue';
  update_iris_colour();

}

function grey_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'grey';
  update_iris_colour();
}

function green_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = 'green';
  update_iris_colour();
}

function lightbrown_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  window.irisColour = "lightbrown";
  update_iris_colour();

}

function lighterbrown_iris()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

   window.irisColour = "lightbrown2";
   update_iris_colour();
}

//################### Functions for background colors #############################
function back_white()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  sceneViewer.setBackgroundColourRGB(1.0, 1.0, 1.0);
}

function back_black()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  sceneViewer.setBackgroundColourRGB(0.0, 0.0, 0.0);
}

function back_bluey()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  sceneViewer.setBackgroundColourRGB(0.1, 0.1, 0.2);
}

//################### Function for Iris size slider ####################################
function iris_slider()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
	
  var irisSlider = document.getElementById("iris-slider");

  // These attributes must be specified in the xul so that they are fetchable
  irisSlider.maxValue = irisSlider.getAttribute("maxpos");
  irisSlider.value = irisSlider.getAttribute("curpos");

  // Unfortunately we are grabbing mouse move events and we have to check if 
  // the value has actually changed.
  if (irisSlider.previousValue != irisSlider.value)
  {
	irisSlider.previousValue = irisSlider.value;

   	window.commandData.executeCommand("gfx define field pupil_time constant " + irisSlider.value / irisSlider.maxValue);
  }
}

//################### Functions for length slider ####################################

function length_slider()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
	
  var lengthSlider = document.getElementById("length-slider");

  // These attributes must be specified in the xul so that they are fetchable
  lengthSlider.maxValue = lengthSlider.getAttribute("maxpos");
  lengthSlider.value = lengthSlider.getAttribute("curpos");

  // Unfortunately we are grabbing mouse move events and we have to check if 
  // the value has actually changed.
  if (lengthSlider.previousValue != lengthSlider.value)
  {
	lengthSlider.previousValue = lengthSlider.value;

   	window.commandData.executeCommand("gfx define field length_time constant " + ((lengthSlider.value / lengthSlider.maxValue) * 2.0 + (-1.0)));  
  }
}
//################### Functions for focus slider ####################################
function focus_slider()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
	
  var focusSlider = document.getElementById("focus-slider");

  // These attributes must be specified in the xul so that they are fetchable
  focusSlider.maxValue = focusSlider.getAttribute("maxpos");
  focusSlider.value = focusSlider.getAttribute("curpos");

  // Unfortunately we are grabbing mouse move events and we have to check if 
  // the value has actually changed.
  if (focusSlider.previousValue != focusSlider.value)
  {
	focusSlider.previousValue = focusSlider.value;

	window.sliderFocalDepth = (focusSlider.value / focusSlider.maxValue) * window.rangeFocalDepth + window.minimumFocalDepth; 

	update_depth_of_field();

   	window.commandData.executeCommand("gfx define field lens_time constant " + ((focusSlider.value / focusSlider.maxValue) * 0.5 + (-0.5))); 

   	//window.commandData.executeCommand("gfx define field rays_time constant " + ((focusSlider.value / focusSlider.maxValue) * 2.0 + (-1.0))); 

  }
}

function update_depth_of_field()
{
	netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	if(window.simulateDepth)
	{
 	  window.depthOfField = 0.015;
	}
        else
	{
 	  window.depthOfField = 0.0;
	}
	window.sceneViewer.setDepthOfField(window.depthOfField, window.sliderFocalDepth + window.offsetFocalDepth);
}

function simulate_depth_of_field()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  var simulateDepthOfField = document.getElementById("simulate-depth-of-field");

if ("true" == simulateDepthOfField.getAttribute("checked"))
	{
	window.simulateDepth = true;
	}
else
	{
	window.simulateDepth = false;
	}
  update_depth_of_field();
}

function normal_eye_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.commandData.executeCommand("gfx define field length_time constant 0.0");
  window.offsetFocalDepth = 0.0;

  update_depth_of_field();
}

function short_sighted_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.commandData.executeCommand("gfx define field length_time constant 0.8");
  window.offsetFocalDepth = -0.2;

  update_depth_of_field();

}

function long_sighted_toggled()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
  window.commandData.executeCommand("gfx define field length_time constant -1.0");
  window.offsetFocalDepth = 0.2;

  update_depth_of_field();

}


//################### Functions for display lines and surfaces ######################
function lines_on()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var displayLines = document.getElementById("lines-on");

if ("true" == displayLines.getAttribute("checked"))
	{
  window.commandData.executeCommand("$is_delete = '';");
  window.commandData.executeCommand("open comfile memory:/elements_on.com exec;");
  window.sceneViewer.perturbLines = true;
	}
else
	{
  window.commandData.executeCommand("$is_delete = 'delete';");
  window.commandData.executeCommand("open comfile memory:/elements_on.com exec;");
  window.sceneViewer.perturbLines = false;
	}
}

function surfaces_on()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

  var displaySurfaces = document.getElementById("surfaces-on");

if ("true" == displaySurfaces.getAttribute("checked"))
	{
  window.commandData.executeCommand("$is_delete = '';");
  window.commandData.executeCommand("open comfile memory:/surfaces_on.com exec;");

  window.surfacesVisible = true;
  update_iris_colour();

	}
else
	{
  window.commandData.executeCommand("$is_delete = 'delete';");
  window.commandData.executeCommand("open comfile memory:/surfaces_on.com exec;");

  window.surfacesVisible = false;
  update_iris_colour();

	}
}

function run_tests()
{
  netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");

	toggle_medrect();
	toggle_latrect();
	toggle_infrec();
	brown_iris();
}
